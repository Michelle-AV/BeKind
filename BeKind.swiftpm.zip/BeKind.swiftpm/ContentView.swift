import SwiftUI

struct ContentView: View {
    @State private var objectPosition = CGPoint(x: 0, y: 0)
    @State private var isButtonPressed = false
    @State private var direction: CGFloat = 0
    @State private var backgroundPositionX: CGFloat = 0
    @State private var isFlipped = false
    
    //popup
    
    @State private var showLouDialog = true
    @State private var isLouHappy = false
    
    @State private var showGatinDialog = true
    @State private var isGatinHappy = false
    
    @State private var showTogiDialog = true
    @State private var isTogiHappy = false

    @State private var showPepeDialog = true
    @State private var isPepeHappy = false
    
    @State private var showMoniDialog = true
    @State private var isMoniHappy = false
    
    
    
    let moveAmount: CGFloat = 4.0
    let backgroundMoveAmount: CGFloat = 2.0

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                let louPositionX = backgroundPositionX - 800
                let gatinPositionX = backgroundPositionX - 350
                
                
                
                Image("bg-color")
                    .resizable()
                    .scaledToFit()
                    .frame(width: geometry.size.width * 3)
                    .offset(x: backgroundPositionX - 350, y: 0)
                
                Image("camino-sin-sombras")
                    .resizable()
                    .scaledToFit()
                    .frame(width: geometry.size.width * 3)
                    .offset(x: backgroundPositionX - 350, y: 0)
                
                Image("pinos-sombra")
                    .resizable()
                    .scaledToFit()
                    .frame(width: geometry.size.width * 3)
                    .offset(x: backgroundPositionX - 350, y: 0)
                
                
               
                
                if !isLouHappy {
                    LouTriste()
                        .scaleEffect(CGSize(width: 0.5, height: 0.5))
                        .offset(x: louPositionX, y: 225)
                        .onTapGesture {
                            if abs(louPositionX - objectPosition.x) <= 200 {
                                self.showLouDialog = true
                            }
                        }
                }
                else{
                    LouFeliz()
                        .scaleEffect(CGSize(width: 0.5, height: 0.5))
                        .offset(x: backgroundPositionX - 800, y: 225)
                }
                
                if !isGatinHappy{
                    
                    GatinTriste()
                        .scaleEffect(CGSize(width: 0.7, height: 0.7))
                        .offset(x: backgroundPositionX - 350, y: 195)
                        .onTapGesture {
                            self.showGatinDialog = true
                        }
                }
                else{
                    GatinFeliz()
                        .scaleEffect(CGSize(width: 0.7, height: 0.7))
                        .offset(x: backgroundPositionX - 350, y: 195)
                }
                
                if !isTogiHappy{
                    
                    TogiTriste()
                        .scaleEffect(CGSize(width: 0.7, height: 0.7))
                        .offset(x: backgroundPositionX - 180, y: 195)
                        .onTapGesture {
                            self.showTogiDialog = true
                        }
                }
                else{
                    TogiFeliz()
                        .scaleEffect(CGSize(width: 0.7, height: 0.7))
                        .offset(x: backgroundPositionX - 180, y: 195)
                }
                
                if !isPepeHappy{
                    
                    PepeTriste()
                        .scaleEffect(CGSize(width: 0.7, height: 0.7))
                        .offset(x: backgroundPositionX + 200, y: 195)
                        .onTapGesture {
                            self.showPepeDialog = true
                        }
                }
                else{
                    PepeFeliz()
                        .scaleEffect(CGSize(width: 0.7, height: 0.7))
                        .offset(x: backgroundPositionX + 200, y: 195)
                }
                
                
                if !isMoniHappy{
                    
                    MoniTriste()
                        .scaleEffect(CGSize(width: 0.7, height: 0.7))
                        .offset(x: backgroundPositionX + 800, y: 195)
                        .onTapGesture {
                            self.showMoniDialog = true
                        }
                }
                else{
                    MoniFeliz()
                        .scaleEffect(CGSize(width: 0.7, height: 0.7))
                        .offset(x: backgroundPositionX + 800, y: 195)
                }
                
                
                
                
                Group {
                    if isButtonPressed {
                        DoggoFeliz()
                            .scaleEffect(x: isFlipped ? -1 : 1, y: 1, anchor: .center) // Voltea el personaje
                            .offset(y: 320)
                            .scaleEffect(CGSize(width: 0.7, height: 0.7))
                        
                        
                    } else {
                        DogoChill()
                            .scaleEffect(x: isFlipped ? -1 : 1, y: 1, anchor: .center)
                            .offset(y: 320)
                            .scaleEffect(CGSize(width: 0.7, height: 0.7))
                        
                        
                    }
                }
                .frame(width: 200)
                .position(x: geometry.size.width / 2 + objectPosition.x, y: geometry.size.height / 2)
                

                Image("arbustosEnFrente")
                    .resizable()
                    .scaledToFit()
                    .frame(width: geometry.size.width * 3)
                    .offset(x: backgroundPositionX - 172, y: 293)
                
                HStack(spacing: 950) {
                    Button(action: {}) {
                        controlButtonLabel("arrow.left")
                    }
                    .buttonStyle(PlainButtonStyle())
                    .disabled(isButtonPressed && direction != -1) // Deshabilitar si otro botón está presionado
                    .onLongPressGesture(minimumDuration: .infinity, pressing: { pressing in
                        if pressing {
                            self.direction = -1
                            self.isButtonPressed = true
                            self.isFlipped = false // Voltea al personaje a la izquierda
                        } else {
                            self.isButtonPressed = false
                        }
                    }) {
                        self.isButtonPressed = false
                    }
                    
                    // Botón para mover hacia la derecha
                    Button(action: {}) {
                        controlButtonLabel("arrow.right")
                    }
                    .buttonStyle(PlainButtonStyle())
                    .disabled(isButtonPressed && direction != 1) // Deshabilitar si otro botón está presionado
                    .onLongPressGesture(minimumDuration: .infinity, pressing: { pressing in
                        if pressing {
                            self.direction = 1
                            self.isButtonPressed = true
                            self.isFlipped = true
                        } else {
                            self.isButtonPressed = false
                        }
                    }) {
                        self.isButtonPressed = false
                    }
                }
                .padding(.horizontal, 20)
                .position(x: geometry.size.width / 2, y: geometry.size.height - 50) // Ajusta la posición de los botones si es necesario
                
                if showLouDialog {
                    ZStack {
                        VStack(spacing: 20) {
                            Text("Me pica la cola, ¿me rascas?")
                                .foregroundColor(.white)
                                .padding()
                                .background(Color.blue)
                                .cornerRadius(10)

                            Button(action: {
                                self.isLouHappy = true
                                self.showLouDialog = false
                            }) {
                                Text("Sí")
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(Color.green)
                                    .cornerRadius(10)
                            }
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(15)
                        .shadow(radius: 10)
                        .offset(x: backgroundPositionX - 800, y: -70)

                    }
                }
                
                if showGatinDialog {
                    ZStack {

                        VStack(spacing: 20) {
                            Text("Me pica la cola, ¿me rascas?")
                                .foregroundColor(.white)
                                .padding()
                                .background(Color.blue)
                                .cornerRadius(10)

                            Button(action: {
                                self.isGatinHappy = true
                                self.isTogiHappy = true
                                self.showGatinDialog = false
                            }) {
                                Text("Sí")
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(Color.green)
                                    .cornerRadius(10)
                            }
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(15)
                        .shadow(radius: 10)
                        .offset(x: backgroundPositionX - 350, y: -70)

                    }
                }
                
                if showTogiDialog {
                    ZStack {

                        VStack(spacing: 20) {
                            Text("Me pica la cola, ¿me rascas?")
                                .foregroundColor(.white)
                                .padding()
                                .background(Color.blue)
                                .cornerRadius(10)

                            Button(action: {
                                self.isTogiHappy = true
                                self.isGatinHappy = true
                                self.showTogiDialog = false
                            }) {
                                Text("Sí")
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(Color.green)
                                    .cornerRadius(10)
                            }
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(15)
                        .shadow(radius: 10)
                        .offset(x: backgroundPositionX - 180, y: -70)

                    }
                }
                
                if showPepeDialog {
                    ZStack {

                        VStack(spacing: 20) {
                            Text("Me pica la cola, ¿me rascas?")
                                .foregroundColor(.white)
                                .padding()
                                .background(Color.blue)
                                .cornerRadius(10)

                            Button(action: {
                                self.isPepeHappy = true
                                self.showPepeDialog = false
                            }) {
                                Text("Sí")
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(Color.green)
                                    .cornerRadius(10)
                            }
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(15)
                        .shadow(radius: 10)
                        .offset(x: backgroundPositionX + 200, y: -70)

                    }
                }
                
                if showMoniDialog {
                    ZStack {

                        VStack(spacing: 20) {
                            Text("Me pica la cola, ¿me rascas?")
                                .foregroundColor(.white)
                                .padding()
                                .background(Color.blue)
                                .cornerRadius(10)

                            Button(action: {
                                self.isMoniHappy = true
                                self.showMoniDialog = false
                            }) {
                                Text("Sí")
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(Color.green)
                                    .cornerRadius(10)
                            }
                        }
                        .padding()
                        .background(Color.white)
                        .cornerRadius(15)
                        .shadow(radius: 10)
                        .offset(x: backgroundPositionX + 800, y: -70)

                    }
                }


            }
            .ignoresSafeArea()
            .onChange(of: isButtonPressed) { _ in updatePositionRepeatedly(geometry: geometry.size) }
        }
    }

    private func controlButtonLabel(_ systemName: String) -> some View {
        Image(systemName: systemName)
            .font(.largeTitle)
            .foregroundColor(.white)
            .padding()
            .background(Circle().fill(Color.blue))
    }

    private func updatePositionRepeatedly(geometry: CGSize) {
        guard isButtonPressed else { return }
        let fixedMoveAmount = direction * moveAmount
        updateObjectPosition(fixedMoveAmount, geometry: geometry)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.02) {
            self.updatePositionRepeatedly(geometry: geometry)
        }
    }

    private func updateObjectPosition(_ deltaX: CGFloat, geometry: CGSize) {
        
        
        let newPositionX = objectPosition.x + deltaX
        let maxRightPosition = geometry.width / 2 - 400
        let maxLeftPosition = -geometry.width / 2 + 200

        objectPosition.x = min(max(newPositionX, maxLeftPosition), maxRightPosition)

        let maxBackgroundPositionX = -geometry.width * 1.40
        let minBackgroundPositionX: CGFloat = 0

        let shouldMoveBackgroundToLeft = newPositionX <= maxLeftPosition + 250 && direction < 0 && backgroundPositionX < minBackgroundPositionX
        let shouldMoveBackgroundToRight = newPositionX >= maxRightPosition - 250 && direction > 0 && backgroundPositionX > maxBackgroundPositionX

        if shouldMoveBackgroundToLeft {
            backgroundPositionX = min(backgroundPositionX + backgroundMoveAmount, minBackgroundPositionX)
        } else if shouldMoveBackgroundToRight {
            backgroundPositionX = max(backgroundPositionX - backgroundMoveAmount, maxBackgroundPositionX)
        }
    }

}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

