import SwiftUI

struct LouFeliz: View {
    @State private var animate = false
    @State private var rotationAngle: Double = 0

    var body: some View {
        VStack {
            Spacer()
            
            ZStack{
                
                Image("flor1")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 50 : 60)
                    .offset(x: 17, y:-240)
                    .offset(x: !animate ? 0 : 0, y: animate ? 5 : 3)
                    .scaleEffect(x: -1)

                Image("star1")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 20 : 30)
                    .offset(x: 80, y:-140)
                    .offset(x: !animate ? 0 : 0, y: animate ? 5 : 3)
                    .scaleEffect(x: -1)

                
                Image("flor2")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 40 : 30)
                    .offset(x: -140, y:-50)
                    .offset(x: !animate ? 0 : 0, y: animate ? 5 : 3)
                    .scaleEffect(x: -1)


                Image("flor1")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 10 : 20)
                    .offset(x: -90, y:-140)
                    .offset(x: !animate ? 0 : 0, y: animate ? 5 : 3)
                    .scaleEffect(x: -1)

                
                Image("star2")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 10 : 20)
                    .offset(x: -26, y:-160)
                    .offset(x: !animate ? 0 : 0, y: animate ? 5 : 3)
                    .scaleEffect(x: -1)

                
                
                Image("star3")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 35 : 25)
                    .offset(x: -71,y:-209)
                    .offset(x: !animate ? 0 : 0, y: animate ? 8 : 2)
                    .scaleEffect(x: -1)

                
                Image("star2")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 40 : 50)
                    .offset(x: 41,y:-159)
                    .offset(x: !animate ? 0 : 0, y: animate ? 8 : 2)
                    .scaleEffect(x: -1)

                Image("flor1")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 50 : 54)
                    .offset(x: 120,y:-89)
                    .offset(x: !animate ? 0 : 0, y: animate ? 8 : 2)
                    .scaleEffect(x: -1)


                Image("star1")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 35 : 20)
                    .offset(x: -121,y:-119)
                    .offset(x: !animate ? 0 : 0, y: animate ? 8 : 2)
                    .scaleEffect(x: -1)
                
                Image("caraLou")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 230)
                    .offset(x: 17, y:-84)
                    .offset(x: !animate ? 0 : 0, y: animate ? 7 : 6)
                
                Image("bocaLouFeliz")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 40)
                    .offset(x: 13,y: -8)
                    .offset(x: !animate ? 0 : 0, y: animate ? 9 : 7)

                Image("ojosLouFeliz")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 105 : 104)
                    .offset(x: 14,y:-52)
                    .offset(x: !animate ? 0 : 0, y: animate ? 7 : 6)

                Image("brazoDerLouFeliz")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 85 : 80)
                    .offset(x:102, y:43)
                    .offset(x: !animate ? 0 : 0, y: animate ? 2 : 0)

                Image("brazoIzqLouFeliz")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 85 : 80)
                    .offset(x:-71, y:43)
                    .offset(x: !animate ? 0 : 0, y: animate ? 0 : 2)
                
                Image("piernaLouFeliz")
                    .resizable()
                    .scaledToFit()
//                    .frame(width: animate ? 21 : 25)
                    .offset(x: -14, y:94)
                    .frame(width: animate ? 40 : 41)
                    .offset(x: !animate ? 0 : 0, y: animate ? 3 : 2)
                
                Image("piernaLouFeliz")
                    .resizable()
                    .scaledToFit()
//                    .frame(width: animate ? 25 : 21)
                    .frame(width: animate ? 40 : 41)
                    .offset(x: 46, y:94)
                    .offset(x: !animate ? 0 : 0, y: animate ? 3 : 2)
                
                Image("cuerpoLou")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 163 : 160)
                    .offset(x:16, y:64)
                    .offset(x: !animate ? 0 : 0, y: animate ? 7 : 6)
                
                Image("LouFelizBase")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 290)
                    .offset(x: 6, y:-40)

                    .offset()
                    .opacity(0)

                            }
            // La animación aquí debería ser ajustada para reflejar el estado deseado sin necesidad de cambio de estado
            .animation(Animation.easeInOut(duration: 0.2).repeatForever(autoreverses: true), value: animate)
            
            Spacer()
        }
        .onAppear {
            self.animate = true
        }
    }
}

struct LouFeliz_Previews: PreviewProvider {
    static var previews: some View {
        LouFeliz()
    }
}


