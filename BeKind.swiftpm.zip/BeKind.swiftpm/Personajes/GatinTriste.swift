import SwiftUI

struct GatinTriste: View {
    @State private var animate = false
    @State private var rotationAngle: Double = 0

    var body: some View {
        VStack {
            Spacer()
            
            ZStack{
                
                Image("colaGato")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 143 : 130)
                    .offset(x:-66, y:47)
                    .offset(x: !animate ? 0 : 0, y: animate ? 7 : 6)
                Image("piernaIzqGato")
                    .resizable()
                    .scaledToFit()
//                    .frame(width: animate ? 21 : 25)
                    .offset(x: -14, y:114)
                    .frame(width: animate ? 25 : 25)

                    .offset(x: !animate ? 0 : 0, y: animate ? 3 : 2)
                
                Image("piernaDerGato")
                    .resizable()
                    .scaledToFit()
//                    .frame(width: animate ? 25 : 21)
                    .frame(width: 25)

                    .offset(x: 26, y:114)
                    .offset(x: !animate ? 0 : 0, y: animate ? 3 : 2)

                Image("brazoDerGato")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 55 : 50)
                    .offset(x:66, y:67)
                    .offset(x: !animate ? 0 : 0, y: animate ? 0 : 2)
                
                Image("brazoIzqGato")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 52 : 50)
                    .offset(x:-51, y:67)
                    .offset(x: !animate ? 0 : 0, y: animate ? 0 : 2)

                Image("cuerpoGato")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 103 : 100)
                    .offset(x:6, y:67)
                    .offset(x: !animate ? 0 : 0, y: animate ? 7 : 6)
                
                

                Image("cabezaGato")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 187)
                    .offset(y:-24)
                    .offset(x: !animate ? 0 : 0, y: animate ? 7 : 6)
                
                Image("narizGato")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 54)
                    .offset(x: 9, y: -4)
                    .offset(x: !animate ? 0 : 0, y: animate ? 9 : 3)
                
                Image("craneo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 50 : 60)
                    .offset(x: 17, y:-110)
                    .offset(x: !animate ? 0 : 0, y: animate ? 5 : 3)

                Image("star1")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 20 : 30)
                    .offset(x: 80, y:-100)
                    .offset(x: !animate ? 0 : 0, y: animate ? 5 : 3)
                
                Image("star1")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 40 : 30)
                    .offset(x: -120, y:-50)
                    .offset(x: !animate ? 0 : 0, y: animate ? 5 : 3)

                Image("star3")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 10 : 20)
                    .offset(x: -90, y:-120)
                    .offset(x: !animate ? 0 : 0, y: animate ? 5 : 3)
                
                Image("star2")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 10 : 20)
                    .offset(x: -26, y:-120)
                    .offset(x: !animate ? 0 : 0, y: animate ? 5 : 3)
                
                
                Image("Asset 13")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 35 : 45)
                    .offset(x: -61,y:-49)
                    .offset(x: !animate ? 0 : 0, y: animate ? 8 : 2)
                
                Image("bomba")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 55 : 50)
                    .offset(x: -101,y:-89)
                    .offset(x: !animate ? 0 : 0, y: animate ? 8 : 2)
                Image("humo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 50 : 54)
                    .offset(x: 120,y:-89)
                    .offset(x: !animate ? 0 : 0, y: animate ? 8 : 2)
                
                Image("humo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 50 : 54)
                    .offset(x: 50,y: -140)
                    .offset(x: !animate ? 0 : 0, y: animate ? 8 : 2)
                    .rotationEffect(Angle(degrees: 60))
                Image("rayo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 45 : 50)
                    .offset(x: -61,y:-119)
                    .offset(x: !animate ? 0 : 0, y: animate ? 8 : 2)
                
                
                Image("ojoIzqGato")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 36)
                    .offset(x: -29,y:-35)
                    .offset(x: !animate ? 0 : 0, y: animate ? 9 : 3)
                
                Image("ojoDerGato")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 36)
                    .offset(x: 52,y:-32)
                    .offset(x: !animate ? 0 : 0, y: animate ? 9 : 3)
                
                    
                Image("")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 290)
                    .offset(x: 9, y: -2)
                    .opacity(0.5)
                

                            }
            // La animación aquí debería ser ajustada para reflejar el estado deseado sin necesidad de cambio de estado
            .animation(Animation.easeInOut(duration: 0.2).repeatForever(autoreverses: true), value: animate)
            
            Spacer()
        }
        .onAppear {
            self.animate = true
        }
    }
}

struct GatinTriste_Previews: PreviewProvider {
    static var previews: some View {
        GatinTriste()
    }
}



