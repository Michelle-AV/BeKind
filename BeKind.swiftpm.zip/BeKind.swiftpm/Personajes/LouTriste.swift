import SwiftUI

struct LouTriste: View {
    @State private var animate = false
    @State private var rotationAngle: Double = 0

    var body: some View {
        VStack {
            Spacer()
            
            ZStack{
                
                Image("charcoLagrimas")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 293 : 290)
                    .offset(x:6, y:117)
                    .offset(x: !animate ? 0 : 0, y: animate ? 7 : 6)

                Image("derLou")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 55 : 50)
                    .offset(x:102, y:93)
                    .offset(x: !animate ? 0 : 0, y: animate ? -4 : 2)
                
                Image("izqLou")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 52 : 50)
                    .offset(x:-81, y:93)
                    .offset(x: !animate ? 0 : 0, y: animate ? -4 : 2)

                Image("cuerpoLou")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 163 : 160)
                    .offset(x:6, y:77)
                    .offset(x: !animate ? 0 : 0, y: animate ? 7 : 6)
                
                Image("caraLou")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 200)
                    .offset(x: 7, y:-54)
                    .offset(x: !animate ? 0 : 0, y: animate ? 7 : 6)
                
                Image("bocaLou")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 40)
                    .offset(x: 10,y: 18)
                    .offset(x: !animate ? 0 : 0, y: animate ? 9 : 7)
                
                Image("ojoIzqLou")
                    .resizable()
                    .frame(width: 50, height: animate ? 85 : 90)

                    .offset(x: -26,y:14)
                    .offset(x: !animate ? 0 : 0, y: animate ? 7 : 6)

                Image("ojoDerLou")
                    .resizable()
                    .frame(width: 50, height: animate ? 85 : 90)
                    .offset(x: 43,y:14)
                    .offset(x: !animate ? 0 : 0, y: animate ? 7 : 6)

                Image("piernaLou")
                    .resizable()
                    .scaledToFit()
//                    .frame(width: animate ? 21 : 25)
                    .offset(x: -14, y:94)
                    .frame(width: animate ? 40 : 41)
                    .offset(x: !animate ? 0 : 0, y: animate ? 3 : 2)
                
                Image("piernaLou")
                    .resizable()
                    .scaledToFit()
//                    .frame(width: animate ? 25 : 21)
                    .frame(width: animate ? 40 : 41)
                    .offset(x: 46, y:94)
                    .offset(x: !animate ? 0 : 0, y: animate ? 3 : 2)
                
//                Image("louBase")
//                    .resizable()
//                    .scaledToFit()
//                    .frame(width: 290)
//                    .offset()
//                    .opacity(0.2)

                            }
            // La animación aquí debería ser ajustada para reflejar el estado deseado sin necesidad de cambio de estado
            .animation(Animation.easeInOut(duration: 0.2).repeatForever(autoreverses: true), value: animate)
            
            Spacer()
        }
        .onAppear {
            self.animate = true
        }
    }
}

struct LouTriste_Previews: PreviewProvider {
    static var previews: some View {
        LouTriste()
    }
}



