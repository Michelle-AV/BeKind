import SwiftUI

struct TogiFeliz: View {
    @State private var animate = false
    @State private var rotationAngle: Double = 0

    var body: some View {
        VStack {
            Spacer()
            
            ZStack{
                Image("flor1")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 50 : 60)
                    .offset(x: -78, y:-150)
                    .offset(x: !animate ? 0 : 0, y: animate ? 5 : 3)
                    .scaleEffect(x: -1)

                Image("star1")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 20 : 30)
                    .offset(x: 80, y:-130)
                    .offset(x: !animate ? 0 : 0, y: animate ? 5 : 3)
                    .scaleEffect(x: -1)

                
                Image("flor2")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 40 : 30)
                    .offset(x: -120, y:-50)
                    .offset(x: !animate ? 0 : 0, y: animate ? 5 : 3)
                    .scaleEffect(x: -1)


                Image("flor1")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 10 : 20)
                    .offset(x: -90, y:-110)
                    .offset(x: !animate ? 0 : 0, y: animate ? 5 : 3)
                    .scaleEffect(x: -1)

                
                Image("star2")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 10 : 20)
                    .offset(x: -26, y:-160)
                    .offset(x: !animate ? 0 : 0, y: animate ? 5 : 3)
                    .scaleEffect(x: -1)

                
                
                Image("star3")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 35 : 25)
                    .offset(x: -71,y:-209)
                    .offset(x: !animate ? 0 : 0, y: animate ? 8 : 2)
                    .scaleEffect(x: -1)

                
                Image("star2")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 40 : 50)
                    .offset(x: 41,y:-159)
                    .offset(x: !animate ? 0 : 0, y: animate ? 8 : 2)
                    .scaleEffect(x: -1)

                Image("star3")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 50 : 54)
                    .offset(x: 120,y:-89)
                    .offset(x: !animate ? 0 : 0, y: animate ? 8 : 2)
                    .scaleEffect(x: -1)


                Image("star1")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 35 : 20)
                    .offset(x: -121,y:-119)
                    .offset(x: !animate ? 0 : 0, y: animate ? 8 : 2)
                    .scaleEffect(x: -1)
     
                
                Image("piernaIzqTogi")
                    .resizable()
                    .scaledToFit()
//                    .frame(width: animate ? 21 : 25)
                    .offset(x: -14, y:114)
                    .frame(width: animate ? 25 : 25)

                    .offset(x: !animate ? 0 : 0, y: animate ? 3 : 2)
                
                Image("piernaDerTogi")
                    .resizable()
                    .scaledToFit()
//                    .frame(width: animate ? 25 : 21)
                    .frame(width: 25)

                    .offset(x: 26, y:114)
                    .offset(x: !animate ? 0 : 0, y: animate ? 3 : 2)


                Image("brazoIzqTogi")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 52 : 50)
                    .offset(x:-51, y:67)
                    .offset(x: !animate ? 0 : 0, y: animate ? -1 : 4)


                

                Image("cabezaTogiFeliz")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 187)
                    .offset(y:-24)
                    .offset(x: !animate ? 0 : 0, y: animate ? 7 : 6)
                Image("brazoDerFelizTogi")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 55 : 50)
                    .offset(x:66, y:40)
                    .offset(x: !animate ? 0 : 0, y: animate ? 0 : 2)
                    .offset(x: !animate ? 0 : 0, y: animate ? -1 : 4)
                
                Image("cuerpoTogi")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 103 : 100)
                    .offset(x:6, y:67)
                    .offset(x: !animate ? 0 : 0, y: animate ? 7 : 6)
                

                
                
     
                Image("ojoFelizIzqTogi")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 36)
                    .offset(x: -33,y:-25)
                    .offset(x: !animate ? 0 : 0, y: animate ? 4 : 3)
                
                Image("ojoFelizDerTogi")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 36)
                    .offset(x: 42,y:-25)
                    .offset(x: !animate ? 0 : 0, y: animate ? 4 : 3)
                
                Image("narizFelizTogi")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 74)
                    .offset(x: 1, y: -9)
                    .offset(x: !animate ? 0 : 0, y: animate ? 3 : 4)
                    
                Image("")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 300)
                    .offset(x: 4, y: -10)
                    .opacity(0.5)
                

                            }
            // La animación aquí debería ser ajustada para reflejar el estado deseado sin necesidad de cambio de estado
            .animation(Animation.easeInOut(duration: 0.2).repeatForever(autoreverses: true), value: animate)
            
            Spacer()
        }
        .onAppear {
            self.animate = true
        }
    }
}

struct TogiFeliz_Previews: PreviewProvider {
    static var previews: some View {
        TogiFeliz()
    }
}

