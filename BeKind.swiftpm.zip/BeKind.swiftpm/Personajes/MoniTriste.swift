import SwiftUI

struct MoniTriste: View {
    @State private var animate = false
    @State private var rotationAngle: Double = 0

    var body: some View {
        VStack {
            Spacer()
            
            ZStack{
                
                Image("cola")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 93 : 90)
                    .offset(x:96, y:47)
                    .offset(x: !animate ? 0 : 0, y: animate ? 7 : 6)
                
                Image("piernaIzqMoni")
                    .resizable()
                    .scaledToFit()
//                    .frame(width: animate ? 21 : 25)
                    .offset(x: -14, y:114)
                    .frame(width: animate ? 25 : 25)

                    .offset(x: !animate ? 0 : 0, y: animate ? 3 : 2)
                
                Image("piernaDerMoni")
                    .resizable()
                    .scaledToFit()
//                    .frame(width: animate ? 25 : 21)
                    .frame(width: 25)

                    .offset(x: 26, y:114)
                    .offset(x: !animate ? 0 : 0, y: animate ? 3 : 2)

                Image("brazoDerMoni")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 75 : 70)
                    .offset(x:76, y:67)
                    .offset(x: !animate ? 0 : 0, y: animate ? 0 : 2)
                    .offset(x: !animate ? 0 : 0, y: animate ? -1 : 4)

                Image("cabezaMoni")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 257)
                    .offset(x: 10,y:-44)
                    .offset(x: !animate ? 0 : 0, y: animate ? 7 : 6)
                
                
                Image("cuerpoMoni")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 135 : 132)
                    .offset(x:6, y:57)
                    .offset(x: !animate ? 0 : 0, y: animate ? 7 : 6)

           Image("brazoIzqMoni")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 92 : 90)
                    .offset(x:-72, y:47)
                    .offset(x: !animate ? 0 : 0, y: animate ? -1 : 4)
                
                Image("caraMoni")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 121)
                    .offset(x: 8, y: -32)
                    .offset(x: !animate ? 0 : 0, y: animate ? 4 : 2)
                
                Image("ojoIzqMoni")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 36)
                    .offset(x: -23,y:-40)
                    .offset(x: !animate ? 0 : 0, y: animate ? 4 : 3)
                
                Image("ojoDerMoni")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 36)
                    .offset(x: 38,y:-40)
                    .offset(x: !animate ? 0 : 0, y: animate ? 4 : 3)
                
                Image("bocaMoni")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 26)
                    .offset(x: 8,y:-30)
                    .offset(x: !animate ? 0 : 0, y: animate ? 6 : 3)
                
                    
                Image("")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 260)
                    .offset(x: 8, y: 6)
                    .opacity(0.2)
                

                            }
            // La animación aquí debería ser ajustada para reflejar el estado deseado sin necesidad de cambio de estado
            .animation(Animation.easeInOut(duration: 0.2).repeatForever(autoreverses: true), value: animate)
            
            Spacer()
        }
        .onAppear {
            self.animate = true
        }
    }
}

struct MoniTriste_Previews: PreviewProvider {
    static var previews: some View {
        MoniTriste()
    }
}





