import SwiftUI

struct MoniFeliz: View {
    @State private var animate = false
    @State private var rotationAngle: Double = 0

    var body: some View {
        VStack {
            Spacer()
            
            ZStack{
                Image("cola")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 93 : 90)
                    .offset(x:96, y:47)
                    .offset(x: !animate ? 0 : 0, y: animate ? 7 : 6)
                
                
                Image("flor1")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 50 : 60)
                    .offset(x: -23, y:-200)
                    .offset(x: !animate ? 0 : 0, y: animate ? 5 : 3)
                    .scaleEffect(x: -1)

                Image("star1")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 20 : 30)
                    .offset(x: 80, y:-140)
                    .offset(x: !animate ? 0 : 0, y: animate ? 5 : 3)
                    .scaleEffect(x: -1)

                
                Image("flor2")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 40 : 30)
                    .offset(x: -160, y:-70)
                    .offset(x: !animate ? 0 : 0, y: animate ? 5 : 3)
                    .scaleEffect(x: -1)


                Image("flor1")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 10 : 20)
                    .offset(x: -90, y:-150)
                    .offset(x: !animate ? 0 : 0, y: animate ? 5 : 3)
                    .scaleEffect(x: -1)

                
                Image("star2")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 10 : 20)
                    .offset(x: -26, y:-160)
                    .offset(x: !animate ? 0 : 0, y: animate ? 5 : 3)
                    .scaleEffect(x: -1)

                
                
                Image("star3")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 35 : 25)
                    .offset(x: -71,y:-209)
                    .offset(x: !animate ? 0 : 0, y: animate ? 8 : 2)
                    .scaleEffect(x: -1)

                
                Image("star2")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 40 : 50)
                    .offset(x: 41,y:-159)
                    .offset(x: !animate ? 0 : 0, y: animate ? 8 : 2)
                    .scaleEffect(x: -1)

                Image("flor1")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 50 : 54)
                    .offset(x: 120,y:-89)
                    .offset(x: !animate ? 0 : 0, y: animate ? 8 : 2)
                    .scaleEffect(x: -1)


                Image("star1")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 35 : 20)
                    .offset(x: -121,y:-119)
                    .offset(x: !animate ? 0 : 0, y: animate ? 8 : 2)
                    .scaleEffect(x: -1)
                

                Image("piernaIzqMoni")
                    .resizable()
                    .scaledToFit()
//                    .frame(width: animate ? 21 : 25)
                    .offset(x: -14, y:114)
                    .frame(width: animate ? 25 : 25)

                    .offset(x: !animate ? 0 : 0, y: animate ? 3 : 2)
                
                Image("piernaDerMoni")
                    .resizable()
                    .scaledToFit()
//                    .frame(width: animate ? 25 : 21)
                    .frame(width: 25)

                    .offset(x: 26, y:114)
                    .offset(x: !animate ? 0 : 0, y: animate ? 3 : 2)

                Image("brazoDerMoniFeliz")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 75 : 70)
                    .offset(x:76, y:37)
                    .offset(x: !animate ? 0 : 0, y: animate ? 0 : 2)
                    .offset(x: !animate ? 0 : 0, y: animate ? -1 : 4)

                Image("cabezaMoni")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 257)
                    .offset(x: 10,y:-44)
                    .offset(x: !animate ? 0 : 0, y: animate ? 7 : 6)
                
                
                Image("cuerpoMoni")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 135 : 132)
                    .offset(x:6, y:57)
                    .offset(x: !animate ? 0 : 0, y: animate ? 7 : 6)

           Image("brazoIzqMoni")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 92 : 90)
                    .offset(x:-72, y:47)
                    .offset(x: !animate ? 0 : 0, y: animate ? -1 : 4)
                
                Image("caraMoni")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 121)
                    .offset(x: 8, y: -32)
                    .offset(x: !animate ? 0 : 0, y: animate ? 4 : 2)
                
                Image("ojoMoniFeliz")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 26)
                    .offset(x: -23,y:-40)
                    .offset(x: !animate ? 0 : 0, y: animate ? 4 : 3)
                
                Image("ojoMoniFeliz")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 26)
                    .offset(x: 38,y:-40)
                    .offset(x: !animate ? 0 : 0, y: animate ? 4 : 3)
                
                Image("bocaMoniFeliz")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 26)
                    .offset(x: 8,y:-30)
                    .offset(x: !animate ? 0 : 0, y: animate ? 6 : 3)
                
                Image("")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 290)
                    .offset(x: 6, y:-20)

                    .offset()
                    .opacity(0.4)

                            }
            // La animación aquí debería ser ajustada para reflejar el estado deseado sin necesidad de cambio de estado
            .animation(Animation.easeInOut(duration: 0.2).repeatForever(autoreverses: true), value: animate)
            
            Spacer()
        }
        .onAppear {
            self.animate = true
        }
    }
}

struct MoniFeliz_Previews: PreviewProvider {
    static var previews: some View {
        MoniFeliz()
    }
}



