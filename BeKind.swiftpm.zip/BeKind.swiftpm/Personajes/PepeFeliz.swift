import SwiftUI

struct PepeFeliz: View {
    @State private var animate = false
    @State private var rotationAngle: Double = 0

    var body: some View {
        VStack {
            Spacer()
            
            ZStack{
                
                Image("flor1")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 50 : 60)
                    .offset(x: -78, y:-150)
                    .offset(x: !animate ? 0 : 0, y: animate ? 5 : 3)
                    .scaleEffect(x: -1)

                Image("star1")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 20 : 30)
                    .offset(x: 80, y:-130)
                    .offset(x: !animate ? 0 : 0, y: animate ? 5 : 3)
                    .scaleEffect(x: -1)

                
                Image("flor2")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 40 : 30)
                    .offset(x: -120, y:-50)
                    .offset(x: !animate ? 0 : 0, y: animate ? 5 : 3)
                    .scaleEffect(x: -1)


                Image("flor1")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 10 : 20)
                    .offset(x: -90, y:-110)
                    .offset(x: !animate ? 0 : 0, y: animate ? 5 : 3)
                    .scaleEffect(x: -1)

                
                Image("star2")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 10 : 20)
                    .offset(x: -26, y:-160)
                    .offset(x: !animate ? 0 : 0, y: animate ? 5 : 3)
                    .scaleEffect(x: -1)

                
                
                Image("star3")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 35 : 25)
                    .offset(x: -71,y:-209)
                    .offset(x: !animate ? 0 : 0, y: animate ? 8 : 2)
                    .scaleEffect(x: -1)

                
                Image("star2")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 40 : 50)
                    .offset(x: 41,y:-159)
                    .offset(x: !animate ? 0 : 0, y: animate ? 8 : 2)
                    .scaleEffect(x: -1)

                Image("star3")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 50 : 54)
                    .offset(x: 120,y:-89)
                    .offset(x: !animate ? 0 : 0, y: animate ? 8 : 2)
                    .scaleEffect(x: -1)


                Image("star1")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 35 : 20)
                    .offset(x: -121,y:-119)
                    .offset(x: !animate ? 0 : 0, y: animate ? 8 : 2)
                    .scaleEffect(x: -1)
     
        
                Image("piernaIzqPepe")
                    .resizable()
                    .scaledToFit()
//                    .frame(width: animate ? 21 : 25)
                    .offset(x: -14, y:114)
                    .frame(width: animate ? 25 : 25)

                    .offset(x: !animate ? 0 : 0, y: animate ? 3 : 2)
                
                Image("piernaDerPepe")
                    .resizable()
                    .scaledToFit()
//                    .frame(width: animate ? 25 : 21)
                    .frame(width: 25)

                    .offset(x: 26, y:114)
                    .offset(x: !animate ? 0 : 0, y: animate ? 3 : 2)

                Image("brazoDerFelizPepe")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 55 : 50)
                    .offset(x:86, y:27)
                    .offset(x: !animate ? 0 : 0, y: animate ? 6 : 2)
                
                Image("brazoIzqFelizPepe")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 52 : 50)
                    .offset(x:-71, y:27)
                    .offset(x: !animate ? 0 : 0, y: animate ? 6 : 2)

                Image("cuerpoPepe")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 133 : 130)
                    .offset(x:9, y:-17)
                    .offset(x: !animate ? 0 : 0, y: animate ? 7 : 6)
                
                Image("ropaPepe")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 143 : 140)
                    .offset(x:9, y:67)
                    .offset(x: !animate ? 0 : 0, y: animate ? 7 : 6)


                Image("bocaPepeFeliz")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 30)
                    .offset(x: 8,y:14)
                    .offset(x: !animate ? 0 : 0, y: animate ? 2 : 2)
                
 
                Image("ojosPepeFeliz")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 86)
                    .offset(x: 7,y:-25)
                    .offset(x: !animate ? 0 : 0, y: animate ? 4 : 3)
  
                Image("")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 240)
                    .offset(x: 15, y: 12)
                    .opacity(0.5)
                


                            }
            // La animación aquí debería ser ajustada para reflejar el estado deseado sin necesidad de cambio de estado
            .animation(Animation.easeInOut(duration: 0.2).repeatForever(autoreverses: true), value: animate)
            
            Spacer()
        }
        .onAppear {
            self.animate = true
        }
    }
}

struct PepeFeliz_Previews: PreviewProvider {
    static var previews: some View {
        PepeFeliz()
    }
}


