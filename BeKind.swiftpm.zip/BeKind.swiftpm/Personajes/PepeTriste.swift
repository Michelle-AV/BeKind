import SwiftUI

struct PepeTriste: View {
    @State private var animate = false
    @State private var rotationAngle: Double = 0

    var body: some View {
        VStack {
            Spacer()
            
            ZStack{
        
                Image("piernaIzqPepe")
                    .resizable()
                    .scaledToFit()
//                    .frame(width: animate ? 21 : 25)
                    .offset(x: -14, y:114)
                    .frame(width: animate ? 25 : 25)

                    .offset(x: !animate ? 0 : 0, y: animate ? 3 : 2)
                
                Image("piernaDerPepe")
                    .resizable()
                    .scaledToFit()
//                    .frame(width: animate ? 25 : 21)
                    .frame(width: 25)

                    .offset(x: 26, y:114)
                    .offset(x: !animate ? 0 : 0, y: animate ? 3 : 2)

                Image("brazoDerPepe")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 55 : 50)
                    .offset(x:86, y:67)
                    .offset(x: !animate ? 0 : 0, y: animate ? 6 : 2)
                
                Image("brazoIzqPepe")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 52 : 50)
                    .offset(x:-71, y:67)
                    .offset(x: !animate ? 0 : 0, y: animate ? 6 : 2)

                Image("cuerpoPepe")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 133 : 130)
                    .offset(x:9, y:-17)
                    .offset(x: !animate ? 0 : 0, y: animate ? 7 : 6)
                
                Image("ropaPepe")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 143 : 140)
                    .offset(x:9, y:67)
                    .offset(x: !animate ? 0 : 0, y: animate ? 7 : 6)


                Image("bocaPepe")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 30)
                    .offset(x: 8,y:4)
                    .offset(x: !animate ? 0 : 0, y: animate ? 2 : 4)
                
                Image("pensamiento1")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 43 : 36)
                    .offset(x: 98,y:-94)
                    .offset(x: !animate ? 0 : 0, y: animate ? 2 : 4)
                
                Image("pensamiento2")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 25 : 30)
                    .offset(x: 98,y:-54)
                    .offset(x: !animate ? 0 : 0, y: animate ? 2 : 4)
                
                Image("ojoIzqPepe")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 36)
                    .offset(x: -21,y:-25)
                    .offset(x: !animate ? 0 : 0, y: animate ? 4 : 3)
                
                Image("ojoDerPepe")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 36)
                    .offset(x: 42,y:-25)
                    .offset(x: !animate ? 0 : 0, y: animate ? 4 : 3)
         
                
                Image("")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 240)
                    .offset(x: 15, y: 12)
                    .opacity(0.5)
                


                            }
            // La animación aquí debería ser ajustada para reflejar el estado deseado sin necesidad de cambio de estado
            .animation(Animation.easeInOut(duration: 0.2).repeatForever(autoreverses: true), value: animate)
            
            Spacer()
        }
        .onAppear {
            self.animate = true
        }
    }
}

struct PepeTriste_Previews: PreviewProvider {
    static var previews: some View {
        PepeTriste()
    }
}

