import SwiftUI

struct DoggoFeliz: View {
    @State private var animate = false
    @State private var rotationAngle: Double = 0

    var body: some View {
        VStack {
            Spacer()
            
            ZStack{

                Image("pierIzqDogo")
                    .resizable()
                    .scaledToFit()
//                    .frame(width: animate ? 21 : 25)
                    .offset(x: -14, y:114)
                    .frame(width: animate ? 25 : 25)

                    .offset(x: !animate ? 0 : 0, y: animate ? 7 : 2)
                
                Image("piernaDerDogo")
                    .resizable()
                    .scaledToFit()
//                    .frame(width: animate ? 25 : 21)
                    .frame(width: 25)

                    .offset(x: 26, y:114)
                    .offset(x: !animate ? 0 : 0, y: animate ? 2 : 7)

                Image("brazoDerDogo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 55 : 50)
                    .offset(x:66, y:67)
                    .offset(x: !animate ? 0 : 0, y: animate ? 5 : 0)
                
                Image("brazoIzqDogo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 52 : 50)
                    .offset(x:-51, y:67)
                    .offset(x: !animate ? 0 : 0, y: animate ? 0 : 5)

                Image("cuerpoDogo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: animate ? 102 : 100)
                    .offset(x:6, y:67)
                    .offset(x: !animate ? 0 : 0, y: animate ? 7 : 6)
                
                

                Image("dogoCabeza")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 200)
                    .offset(y:-24)
                    .offset(x: !animate ? 0 : 0, y: animate ? 7 : 4)
                
                Image("narizDog")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 80)
                    .offset(x: -21,y:-4)
                    .offset(x: !animate ? 0 : 0, y: animate ? 9 : 4)
                
                Image("sombreroDogo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 80)
                    .offset(y:-110)
                    .offset(x: !animate ? 0 : 0, y: animate ? 5 : 3)


                
                
                Circle()
                    .frame(width: 20)
                    .offset(x: -49,y:-35)
                    .offset(x: !animate ? 0 : 0, y: animate ? 7 : 4)
                
                Circle()
                    .frame(width: 20)
                    .offset(x: 12,y:-35)
                    .offset(x: !animate ? 0 : 0, y: animate ? 7 : 4)
                

                            }
            // La animación aquí debería ser ajustada para reflejar el estado deseado sin necesidad de cambio de estado
            .animation(Animation.easeInOut(duration: 0.2).repeatForever(autoreverses: true), value: animate)
            
            Spacer()
        }
        .onAppear {
            self.animate = true
        }
    }
}

struct DoggoFeliz_Previews: PreviewProvider {
    static var previews: some View {
        DoggoFeliz()
    }
}

