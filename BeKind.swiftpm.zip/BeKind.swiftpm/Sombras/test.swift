import SwiftUI

struct sombraMono: View {
    @State private var animate = false
    @State private var rotationAngle: Double = 0

    var body: some View {
        VStack {
            Spacer()
            
            ZStack{
                
                
                Circle()
                    .scaledToFit()
                    .offset(x: -93, y: -3)
                    .frame(width: animate ? 60 : 68)
                    .offset(x: !animate ? 0 : 0, y: animate ? 2 : 2)
                
                Image("brazo-monkey-sombra")
                    .resizable()
                    .scaledToFit()
                    .offset(x: 77, y:56)
                    .frame(height: 64)
                    .offset(x: !animate ? 0 : 0, y: animate ? 2 : 2)
                Image("brazo-monkey-sombra")
                    .resizable()
                    .scaledToFit()
                    .offset(x: 83, y:56)
                    .frame(height: 64)
                    .offset(x: !animate ? 0 : 0, y: animate ? 2 : 2)
                    .scaleEffect(x:-1)
                Circle()
                    .offset(x:87, y: -3)
                    .frame(width: animate ? 60 : 68)
                    .offset(x: !animate ? 0 : 0, y: animate ? 2 : 2)
                Image("pata-sombra")
                    .resizable()
                    .offset(x: 31, y:86)
                    .frame(width: animate ? 20 : 22, height: animate ? 70 :60)
                    .offset(x: !animate ? 0 : 0, y: animate ? 2 : 4)
                Image("pata-sombra")
                    .resizable()
                    .offset(x: 18, y:86)
                    .frame(width: animate ? 20 : 22, height: animate ? 70 :60)
                    .offset(x: !animate ? 0 : 0, y: animate ? 4 : 2)
                
                Image("pata-sombra")
                    .resizable()
                    .offset(x: -31, y:86)
                    .frame(width: animate ? 20 : 22, height: animate ? 70 :60)
                    .offset(x: !animate ? 0 : 0, y: animate ? 2 : 4)
                Image("pata-sombra")
                    .resizable()
                    .offset(x: -18, y:86)
                    .frame(width: animate ? 20 : 22, height: animate ? 70 :60)
                    .offset(x: !animate ? 0 : 0, y: animate ? 4 : 2)
                RoundedRectangle(cornerRadius: 35)
                    .offset(x: -6, y:-7)
                    .frame(width: 180, height: 180)
                    .offset(x: !animate ? 0 : 0, y: animate ? 2 : -5)

                RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                    .fill(.white)
                    .offset(x: -6, y:1)
                    .frame(width: animate ? 119: 119, height: animate ? 70 : 100)

                Image("diente-gato")
                    .resizable()
                    .scaledToFit()
                    .offset(x: -50, y:40)
                    .frame(height: animate ? 60.5 : 74.5)
                    .offset(x: !animate ? 0 : 0, y: animate ? 2 : -6)
                    .scaleEffect(y:-1)
                
                Image("diente-gato")
                    .resizable()
                    .scaledToFit()
                    .offset(x: 30, y:40)
                    .frame(height: animate ? 60.5 : 74.5)
                    .offset(x: !animate ? 0 : 0, y: animate ? 2 : -6)
                    .scaleEffect(y:-1)
                
                Image("diente-gato")
                    .resizable()
                    .scaledToFit()
                    .offset(x: -27, y:36)
                    .frame(height: animate ? 50.5 : 64.5)
                    .offset(x: !animate ? 0 : 0, y: animate ? 2 : 2)
                
                Image("diente-gato")
                    .resizable()
                    .scaledToFit()
                    .offset(x: 21, y:36)
                    .frame(height: animate ? 50.5 : 64.5)
                    .offset(x: !animate ? 0 : 0, y: animate ? 2 : 2)
                
                Image("ojo1-sombra-monkey")
                    .resizable()
                    .scaledToFit()
                    .offset(x: -21, y:-79)
                    .frame(width: animate ? 25 : 27)
                    .offset(x: !animate ? 0 : 0, y: animate ? 8 : 12)


                Image("ojo2-sombra-monkey")
                    .resizable()
                    .scaledToFit()
                    .offset(x: 21, y:-79)
                    .frame(width: animate ? 25 : 27)
                    .offset(x: !animate ? 0 : 0, y: animate ? 8 : 12)
                

                
                Image("")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 260)
                    .offset(x:-5, y:7)
                    .opacity(0.4)
             

                            }
            .animation(Animation.easeInOut(duration: 0.2).repeatForever(autoreverses: true), value: animate)
            
            Spacer()
        }
        .onAppear {
            self.animate = true
        }
    }
}

struct sombraMono_Previews: PreviewProvider {
    static var previews: some View {
        sombraMono()
    }
}
